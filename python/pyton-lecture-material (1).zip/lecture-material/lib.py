# import sys		# System libraries
# print "number of commandline arguments %d" % (len(sys.argv) - 1)
# sys.exit(0)
# print sys.argv[0]
# print sys.argv[1]
# print type(sys.argv[1])




# import math 	# for mathematical operation
# a = 100
# print math.sqrt(a)
# print math.pi
# Has other functions like -
# ceil(x) 	Returns the smallest integer greater than or equal to x.
# fabs(x) 	Returns the absolute value of x
# factorial(x) 	Returns the factorial of x
# floor(x) 	Returns the largest integer less than or equal to x
# isinf(x) 	Returns True if x is a positive or negative infinity
# isnan(x) 	Returns True if x is a NaN
# cos(x) 	Returns the cosine of x
# pi 	Mathematical constant, the ratio of circumference of a circle to it's diameter (3.14159...)
# e 	mathematical constant e (2.71828...)

# Importing libraries

# import os
# os.path.isfile('mg.txt')  # Checks if a file exists
# os.path.isdir('newdir')   # Checks if the given path is a directory
# os.rename( "demofile.txt", "mg.txt" )
# os.remove("dummyfile.txt")

# cwd = os.getcwd()
# print cwd

# dirList = os.listdir(cwd)
# print dirList

# os.mkdir("newdir")

# dirList = os.listdir(cwd)
# print dirList

# os.chdir("newdir")

# new_cwd = cwd.split('/newdir')
# cwd = os.getcwd()
# print cwd
# os.rmdir('newdir')