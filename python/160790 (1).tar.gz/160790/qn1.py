string=raw_input('Enter the number ')
base=input('Enter the base ')
if(base>37):
    print("INVALID INPUT")
    exit(0)
isp=string.find(".")
isneg=string.find("-")
if (isneg!=-1):
    temp=string.split("-")
    string=temp[1]
var=string.split(".")
answer=0
first=var[0]
if(isp!=-1):
    second=var[1]
else:
    second=[]
length2=len(second)
length1=len(first)
isfalse=0
for i in range(0,length1):
    if ((ord(first[length1-i-1])>=48 and ord(first[length1-i-1])<=57 ) or (ord(first[length1-i-1])>=65 and ord(first[length1-i-1])<=90 ) ):
        if((ord(first[length1-i-1])>=48 and ord(first[length1-i-1])<=57 )):
            if (base < (ord(first[length1-i-1])-ord('0')+1 ) ):
                isfalse=1
        elif ( (ord(first[length1-i-1])>=65 and ord(first[length1-i-1])<=90 ) ):
            if (base < (ord(first[length1-i-1])-ord('A') ) + 11 ):
                isfalse=1

    else:
        isfalse=1
    if (isfalse==1):
        print("INVALID INPUT")
        exit(0)
    else:
        if((ord(first[length1-i-1])>=48 and ord(first[length1-i-1])<=57 )):
            answer=answer+pow(base,i)*(ord(first[length1-i-1])-ord('0'))
        elif ( (ord(first[length1-i-1])>=65 and ord(first[length1-i-1])<=90 ) ):
            answer=answer+(pow(base,i)*(ord(first[length1-i-1])-ord('A')+10))


if( isp!=-1):
    for i in range(0,length2):
        if ((ord(second[i])>=48 and ord(second[i])<=57 ) or (ord(second[i])>=65 and ord(second[i])<=90 ) ):
            if((ord(second[i])>=48 and ord(second[i])<=57 )):
                if (base < (ord(second[i])-ord('0')+1 ) ):
                    isfalse=1
            elif ( (ord(second[i])>=65 and ord(second[i])<=90 ) ):
                if (base < (ord(second[i])-ord('A') ) + 11 ):
                    isfalse=1

        else:
            isfalse=1
        if (isfalse==1):
            print("INVALID INPUT")
            exit(0)
        else:
            if((ord(second[i])>=48 and ord(second[i])<=57 )):
                answer=answer+pow(base,-(i+1))*(ord(second[i])-ord('0'))
            elif ( (ord(second[i])>=65 and ord(second[i])<=90 ) ):
                answer=answer+pow(base,-(i+1))*(ord(second[i])-ord('A')+10)
if (not(answer<=999999999)):
    print("TOO LARGE NUMBER")
    exit(0)
if(isneg==-1):
    print '%.6f' %answer
else:
    print '-'+'%.6f' %answer
