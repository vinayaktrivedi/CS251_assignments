#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<pthread.h>
#include<sys/time.h>
pthread_mutex_t lock[10000];
int num_tran;
int count=0;
float arr[10000]={0};
float transactions[10000][5];
#define USAGE_EXIT(s) do{ \
                             printf("%s", s); \
                            exit(-1);\
                    }while(0);

#define TDIFF(start, end) ((end.tv_sec - start.tv_sec) * 1000000UL + (end.tv_usec - start.tv_usec))
void calculate(int cntr){
  if(count>=num_tran){

     return;
   }
  else if(transactions[cntr][4]==0){
    if(transactions[cntr][0]==4.0){
      if(pthread_mutex_trylock(&lock[(int)transactions[cntr][2]])==0){
           if(pthread_mutex_trylock(&lock[(int)transactions[cntr][3]])==0){
          arr[(int)transactions[cntr][3]]+=0.99*transactions[cntr][1];
          arr[(int)transactions[cntr][2]]-=1.01*transactions[cntr][1];
          count++;
          transactions[cntr][4]=1;
          pthread_mutex_unlock(&lock[(int)transactions[cntr][3]]);
        }
          pthread_mutex_unlock(&lock[(int)transactions[cntr][2]]);
          calculate((cntr+1)%num_tran);
          return;
    }
    else{
       calculate((cntr+1)%num_tran);
       return;
    }
    }
    else{
        if(pthread_mutex_trylock(&lock[(int)transactions[cntr][2]])==0){

            if(transactions[cntr][0]==1.0){
              arr[(int)transactions[cntr][2]]+=0.99*transactions[cntr][1];
            }
            else if(transactions[cntr][0]==2.0){
              arr[(int)transactions[cntr][2]]-=1.01*transactions[cntr][1];
            }
            else if(transactions[cntr][0]==3.0){
              arr[(int)transactions[cntr][2]]=1.071*arr[(int)transactions[cntr][2]];
            }
            transactions[cntr][4]=1;
            count++;
            pthread_mutex_unlock(&lock[(int)transactions[cntr][2]]);
            calculate((cntr+1)%num_tran);
            return;
        }
        else{

          calculate((cntr+1)%num_tran);
          return;
        }
    }
  }
  else if(transactions[cntr][4]==1.0){

        calculate((cntr+1)%num_tran);
        return;
  }
}
void *function(void *arg){
   calculate(0);
   pthread_exit(NULL);
}
int main(int argc, char **argv) {
    if(argc !=5)
             USAGE_EXIT("not enough parameters");
    num_tran=atoi(argv[3]);
    int num_threads=atoi(argv[4]);
    struct timeval start, end;
    int acc;
    float bal;
    float amount;
    int type,ac1,ac2;
    FILE *fp;
    fp = fopen(argv[1], "rt");
    if (fp == NULL)
        {
        printf("File does not exist");
        exit(1);
        }
     int r;
    while ((r = fscanf(fp, "%d %f", &acc, &bal)) != EOF) {
        if (r == 2) { // Do we get the two matches of "%d %d"?

        arr[acc-1001]=bal;
        }
    }

    fclose(fp);
    fp= fopen(argv[2],"rt");
    if(fp==NULL){
      printf("File does not exist");
      exit(1);
    }
    int temp;
    int i=1;
    int ctr;
    while ((r = fscanf(fp, "%d %d %f %d %d", &temp, &type,&amount,&ac1,&ac2)) != EOF) {
        if (r == 5) { // Do we get the two matches of "%d %d"?
            transactions[i-1][0]=type;
            transactions[i-1][1]=amount;
            transactions[i-1][2]=ac1-1001;
            transactions[i-1][3]=ac2-1001;
            transactions[i-1][4]=0;
            i++;
        }
    }
    fclose(fp);
    pthread_t threads[num_threads];

    for (i=0;i<10000;i++){
       pthread_mutex_init(&lock[i], NULL);
    }
    gettimeofday(&start, NULL);
    for( ctr=0; ctr < num_threads; ++ctr){
       if(pthread_create(&threads[ctr], NULL, function, NULL) != 0){
             perror("pthread_create");
             exit(-1);
       }
    }
    for( ctr=0; ctr < num_threads; ++ctr)
           pthread_join(threads[ctr], NULL);

   for( i=0;i<10000;i++){
      printf("%d %.2f\n",i+1001,arr[i]);
    }
    gettimeofday(&end, NULL);
    printf("Time taken = %ld microsecs\n", TDIFF(start, end));
return 0;

}
