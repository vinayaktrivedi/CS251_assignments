#!/bin/bash
#Took help from internet for 'find' function
totstring=0
totcomment=0
command=`find $1 -type f -name '*.c' -printf '%p\n'`
while read -r filepath 
do 
output=`awk -f qn1.awk "$filepath"`
variable=($output)
totstring=$(($totstring+${variable[0]}))
totcomment=$(($totcomment+${variable[1]}))
done <<< "$command"
echo $totcomment lines of comments
echo $totstring quoted strings
