import os
var=open("threads.txt",'r').read()
threads=var.split()
var=open("params.txt",'r').read()
params=var.split()
if not os.path.exists('./speedup.out'):
    os.mknod('./speedup.out')
f=open('speedup.out','a')
k=0
for i in params:
    f.write(i+" ")
    for j in threads:
        s=open('./average_'+j+'.out','r').read()
        var=s.split("\n")
        l=len(var)
        var=var[:l-1]
        temp=var[k]
        temp=temp.split()
        f.write(temp[1]+" ")
    f.write("\n")
    k=k+1
