import os
import math
var=open("threads.txt",'r').read()
threads=var.split()
var=open("params.txt",'r').read()
params=var.split()
if not os.path.exists('./speedup_error.out'):
    os.mknod('./speedup_error.out')
f=open('speedup_error.out','a')
k=0
for i in params:
    f.write(i+" ")
    for j in threads:
        c=0
        s=open('./scatter_'+j+'.out','r').read()
        var=s.split("\n")
        l=len(var)
        var=var[:l-1]
        for a in range(100):
            temp=var[k+a]
            temp=temp.split()
            c=c+int(temp[1])
        mean=c/100
        variance=0
        for a in range(100):
            temp=var[k+a]
            temp=temp.split()
            variance=variance+(int(temp[1])-mean)**2
        variance=math.sqrt(variance)
        f.write(str(mean)+" "+str(variance)+" ")
    f.write("\n")
    k=k+100
