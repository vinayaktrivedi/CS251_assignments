f=open("input.out",'r').read()
data=f.split("\n")
l=len(data)
data=data[:l-1]
import os
var=open("threads.txt",'r').read()
threads=var.split()
for i in threads:
    if not os.path.exists('./scatter_'+i+'.out'):
        os.mknod('./scatter_'+i+'.out')
for i in threads:
    s=open('./scatter_'+i+'.out','a')
    for j in data:
        var=j.split()
        if(i==var[0]):
            s.write(var[1]+' '+var[2]+'\n')
