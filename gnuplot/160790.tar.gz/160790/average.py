import os
var=open("threads.txt",'r').read()
threads=var.split()
var=open("params.txt",'r').read()
params=var.split()
for i in threads:
    if not os.path.exists('./average_'+i+'.out'):
        os.mknod('./average_'+i+'.out')
for i in threads:
    s=open('./scatter_'+i+'.out','r').read()
    f=open('./average_'+i+'.out','a')
    var=s.split("\n")
    l=len(var)
    var=var[:l-1]
    for j in params:
        c=0
        i=0
        for k in var:
            temp=k.split()
            if(temp[0]==j):
                c=c+int(temp[1])
                i=i+1;
        f.write(j+" "+str(c/i)+"\n")
