import os
if not os.path.exists('./input.out'):
    os.mknod('./input.out')
f = open('input.out', 'r+')
f.truncate()
f.close()
w=open('input.out','a')
f=open("params.txt",'r')
f2=open("threads.txt",'r')
x=f.read()
y=f2.read()
array1=x.split()
array2=y.split()
for a in array2:
    for b in array1:
        for i in range(100):
            c=os.popen("./target_bin "+b+" "+a).read()
            var=c.split()
            w.write(a+" "+b+" "+var[3]+"\n")
