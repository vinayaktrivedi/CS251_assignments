<!DOCTYPE html>
<html lang="en">
<head>
	<title>Portal</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="custom/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="custom/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="custom/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="custom/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>
	<?php
	$db = new SQLite3('mysqlitedb.db');
	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
               $browser=$_SERVER['HTTP_USER_AGENT'];
$ipaddress=$_SERVER['REMOTE_ADDR'];
		$user = test_input($_POST["user"]);
		$pass = test_input($_POST["pass"]);
		$q="SELECT * FROM admin WHERE username='$user' AND password='$pass'";
		$q=$db->query($q);
		$q=$q->fetchArray();
		if($q==NULL){
			echo "<script type='text/javascript'>alert('Invalid Password or username'); window.location.href='/admin.php';</script>";
		}
		else{
			
			$q="UPDATE admin SET loggedin='TRUE',ip='$ipaddress',agent='$browser' WHERE username='vinayakt' ";
			$update=$db->query($q);
		    
				echo "<script type='text/javascript'>alert('Logged In successfully'); window.location.href='/view.php';</script>";
		}
	}
	 ?>
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<h1> <a href="index.php"> Another Registration. </a>
				</div>

				<form class="login100-form validate-form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
					<span class="login100-form-title">
						ADMIN LOGIN
					</span>

					<div class="wrap-input100 validate-input">
						<input class="input100" type="text" name="user" placeholder="Username">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
						</span>
					</div>
					<div class="wrap-input100 validate-input">
						<input class="input100" type="password" name="pass" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
						</span>
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn" type="submit">
							LOGIN
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<script src="custom/jquery/jquery-3.2.1.min.js"></script>
	<script src="custom/bootstrap/js/popper.js"></script>
	<script src="custom/bootstrap/js/bootstrap.min.js"></script>
	<script src="custom/select2/select2.min.js"></script>
	<script src="custom/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
	<script src="js/main.js"></script>
</body>
</html>

