<?php
$browser=$_SERVER['HTTP_USER_AGENT'];
$ipaddress=$_SERVER['REMOTE_ADDR'];
$db = new SQLite3('mysqlitedb.db');
$q="SELECT * FROM admin";
$q=$db->query($q);
$q=$q->fetchArray();
if($browser==$q[4] && $ipaddress==$q[3]){
  $up="UPDATE admin SET ip='nil',agent='nil' WHERE username='vinayakt' ";
$x=$db->query($up);
    echo "<script type='text/javascript'>alert('Signed out successfully'); window.location.href='/';</script>";
}
else{
  echo "<script type='text/javascript'>alert('You are not signed in! Wrong Try!!'); window.location.href='/';</script>";
}
?>

