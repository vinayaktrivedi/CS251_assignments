<!DOCTYPE html>
<html lang="en">
<head>
	<title>Portal</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="custom/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="custom/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="custom/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="custom/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>

	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<h1> <a href="admin.php"> See All Registrations </a>
				</div>

				<form class="login100-form validate-form" method="post" action="validate.php" onsubmit="return check(this);">
					<span class="login100-form-title">
						Bank Member Registration
					</span>

					<div class="wrap-input100 validate-input">
						<input class="input100" type="text" name="email" placeholder="Email">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
						</span>
					</div>

					<div class="wrap-input100 validate-input">
						<input class="input100" type="text" name="name" placeholder="Name">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
						</span>
					</div>
					<div class="wrap-input100 validate-input">
						<input class="input100" type="text" name="address" placeholder="Address">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
						</span>
					</div>
					<div class="wrap-input100 validate-input">
						<input class="input100" type="text" name="mobile" placeholder="Mobile Number">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
						</span>
					</div>
					<div class="wrap-input100 validate-input">
						<input class="input100" type="text" name="account" placeholder="Account Number">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
						</span>
					</div>
					<div class="wrap-input100 validate-input">
						<input class="input100" type="password" name="pass" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
						</span>
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn" type="submit">
							Register
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<script src="custom/jquery/jquery-3.2.1.min.js"></script>
	<script src="custom/bootstrap/js/popper.js"></script>
	<script src="custom/bootstrap/js/bootstrap.min.js"></script>
	<script src="custom/select2/select2.min.js"></script>
	<script src="custom/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
	<script src="js/main.js"></script>
	<script>
  function check(form){
		if(form.name.length==0||form.email.length==0||form.address.length==0||form.pass.length==0){
			alert("Invalid Lengths of input fields");
			return false;
}
		if(form.pass.length>20){
		      alert("Invalid password length");
                        return false;
}
		if(form.address.length>100){
		      alert("Invalid address");
                        return false;
}
		if(form.name.length>20){
		      alert("Invalid name length");
                        return false;
}
		var ph=/^\d{10}$/;
		var acc=/^\d{5}$/;
		if(!ph.test(form.mobile.value)||!acc.test(form.account.value)){
			alert("Invalid Account number or phone");
			return false;
		}
		var p=/^[a-zA-Z0-9]+$/;
		if(!p.test(form.pass.value)){
			alert("Invalid password characters");
			return false;
		}
		var n=/^[a-zA-Z ]+$/;
		var e=/^[a-zA-Z]+$/;
		if(!n.test(form.name.value)){
			alert("Invalid Name characters");
			return false;
		}
		var email=form.email.value;
		var t=email.split("@");
		if(!e.test(t[0])){
			alert("Invalid E-mail");
			return false;
		}
		var temp=t[1].split(".");
		if(temp[1]!='com'||!e.test(temp[0])){
			alert("Invalid E-mail");
			return false;
		}
		return true;
	}

	</script>

</body>
</html>
