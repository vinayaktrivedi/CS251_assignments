<?php
$db = new SQLite3('mysqlitedb.db');
$q= "INSERT INTO accounts (accountnumber,accountbalance,password) VALUES ('20000','2000','home')";
$q=$db->query($q);
$q= "INSERT INTO accounts (accountnumber,accountbalance,password) VALUES ('20001','20000','home1')";
$q=$db->query($q);
$q= "INSERT INTO accounts (accountnumber,accountbalance,password) VALUES ('20002','200','home2')";
$q=$db->query($q);
$q= "INSERT INTO accounts (accountnumber,accountbalance,password) VALUES ('20003','1000','home3')";
$q=$db->query($q);
$q= "INSERT INTO accounts (accountnumber,accountbalance,password) VALUES ('20004','10000','home4')";
$q=$db->query($q);
$q= "INSERT INTO accounts (accountnumber,accountbalance,password) VALUES ('20005','200000','home5')";
$q=$db->query($q);
$q= "INSERT INTO accounts (accountnumber,accountbalance,password) VALUES ('20006','0','home6')";
$q=$db->query($q);
$q= "INSERT INTO accounts (accountnumber,accountbalance,password) VALUES ('20007','2000','home7')";
$q=$db->query($q);
$q= "INSERT INTO accounts (accountnumber,accountbalance,password) VALUES ('20008','18000','home8')";
$q=$db->query($q);
$q= "INSERT INTO accounts (accountnumber,accountbalance,password) VALUES ('20009','200','home9')";
$q=$db->query($q);

?>
