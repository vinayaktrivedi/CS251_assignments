<?php
$db = new SQLite3('mysqlitedb.db');
function test_input($data) {
$data = trim($data);
$data = stripslashes($data);
$data = htmlspecialchars($data);
return $data;
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$name = test_input($_POST["name"]);
$email = test_input($_POST["email"]);
$account = test_input($_POST["account"]);
$mobile = test_input($_POST["mobile"]);
$address = test_input($_POST["address"]);
$pass=test_input($_POST["pass"]);
$sql="SELECT * FROM accounts WHERE accountnumber='$account' AND  password='$pass' ";
$res=$db->query($sql);
$res = $res->fetchArray();
if($res==NULL){
    echo "<script type='text/javascript'>alert('Invalid Password/Account number'); window.location.href='/';</script>";
}else{
  $qstr = "SELECT * FROM records WHERE email='$email' ";
  $results = $db->query($qstr);
  $results = $results->fetchArray();
  if($results==NULL){
      if($res[1]<1000){
    echo  "<script type='text/javascript'>alert('Insufficient balance'); window.location.href='/';</script>";
    }
    else{
      $newbal=$res[1]-1000;
      $insert="INSERT INTO records(accountnumber,name,email,address,mobile) VALUES ('$account','$name','$email','$address','$mobile') ";
      $sql=$db->query($insert);
      $update="UPDATE accounts SET accountbalance='$newbal' WHERE accountnumber='$account' ";
      $sql=$db->query($update);
      echo "<script type='text/javascript'>alert('Registered Successfully'); window.location.href='/';</script>";
    }
  }
  else{
      echo "<script type='text/javascript'>alert('Already Registered'); window.location.href='/';</script>";
  }
}
}
?>

