<!DOCTYPE html>

<html>

<head>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>

<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<!------ Include the above in your HEAD tag ---------->

<style>

.panel-table .panel-body{

  padding:0;

}



.panel-table .panel-body .table-bordered{

  border-style: none;

  margin:0;

}



.panel-table .panel-body .table-bordered > thead > tr > th:first-of-type {

    text-align:center;

    width: 100px;

}



.panel-table .panel-body .table-bordered > thead > tr > th:last-of-type,

.panel-table .panel-body .table-bordered > tbody > tr > td:last-of-type {

  border-right: 0px;

}



.panel-table .panel-body .table-bordered > thead > tr > th:first-of-type,

.panel-table .panel-body .table-bordered > tbody > tr > td:first-of-type {

  border-left: 0px;

}



.panel-table .panel-body .table-bordered > tbody > tr:first-of-type > td{

  border-bottom: 0px;

}



.panel-table .panel-body .table-bordered > thead > tr:first-of-type > th{

  border-top: 0px;

}



.panel-table .panel-footer .pagination{

  margin:0;

}



/*

used to vertically center elements, may need modification if you're not using default sizes.

*/

.panel-table .panel-footer .col{

 line-height: 34px;

 height: 34px;

}



.panel-table .panel-heading .col h3{

 line-height: 30px;

 height: 30px;

}



.panel-table .panel-body .table-bordered > tbody > tr > td{

  line-height: 34px;

}





</style>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>

</head>

<body>
<?php

$db = new SQLite3('mysqlitedb.db');
$browser=$_SERVER['HTTP_USER_AGENT'];
$ipaddress=$_SERVER['REMOTE_ADDR'];
$q="SELECT * FROM admin WHERE ip='$ipaddress' AND agent='$browser' ";

$q=$db->query($q);

$q=$q->fetchArray();
if($q==NULL){  echo "<script type='text/javascript'>alert('This is illegal!'); window.location.href='/';</script>";

}
else{
if($q[2]=='FALSE'){

echo 'SORRY YOU ARE NOT ALLOWED';

}

else{

$data="SELECT * FROM records";

$data=$db->query($data);

?>

<div class="container">
<div class="row">
 <form action="signout.php">
 <button type="submit"> Signout </button>
	</form>
</div>
<div class="row">
  <form action="signout.php">
 <button type="submit"> Another Registration! </button>
        </form>


</div>
</div>
<div class="container">

    <div class="row">

        <div class="col-md-10 col-md-offset-1">



            <div class="panel panel-default panel-table">

              <div class="panel-heading">

                <div class="row">

                  <div class="col col-xs-6">

                    <h3 class="panel-title">User data</h3>

                  </div>

                </div>

              </div>

              <div class="panel-body">

                <table class="table table-striped table-bordered table-list">

                  <thead>

                    <tr>

                        <th>E-Mail</th>

                        <th>Name</th>

                        <th>Account Number</th>
			<th> Address </th>
			<th> Mobile Number </th>

                    </tr>

                  </thead>

                  <tbody>
		<?php
		while($row=$data->fetchArray()){
                         echo '<tr>';

	                          echo '<td>'.$row[2].'</td>';

                                echo '<td>'.$row[1].'</td>';

                                echo '<td>'.$row[0].'</td>';
				    echo '<td>'.$row[3].'</td>';
				    echo '<td>'.$row[4].'</td>';
                          echo '</tr>';
		}
			?>

                        </tbody>

                </table>



              </div>



            </div>



</div></div></div>
<?php
}
}
?>

</body>

</html>
